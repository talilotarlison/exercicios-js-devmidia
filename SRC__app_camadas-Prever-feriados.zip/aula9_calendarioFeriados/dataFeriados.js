const feriadosNacionais = [
    { nome: 'Confraternização universal',   data: '01/01'},
    { nome: 'Tiradentes',                   data: '04/21'},
    { nome: 'Dia do trabalho',              data: '05/01'},
    { nome: 'Independência do Brasil',      data: '09/07'},
    { nome: 'Nossa senhora aparecida',      data: '10/12'},
    { nome: 'Finados',                      data: '11/02'},
    { nome: 'Proclamação da república',     data: '11/15'},
    { nome: 'Natal',                        data: '12/25'},
];

export default feriadosNacionais;

