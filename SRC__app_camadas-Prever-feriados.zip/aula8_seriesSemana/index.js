import retornaSerieDia from './retornoSerie.js';

let serieDoDia = retornaSerieDia();

console.log("Serie do dia: "+serieDoDia);






